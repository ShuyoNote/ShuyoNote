register({ id: "fixture-plugin.noop", title: "什么都不做", description: "", closeOnRun: true, run: function(){ return "ok"; } });
